let x = 50;
let y = 40;

console.log(x+y);
